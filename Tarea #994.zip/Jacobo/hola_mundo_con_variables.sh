#!bin/bash

Nombre=""

echo -n "Ingresa tu nombre: "
read Nombre

echo -e "\033[40m\033[36m Este Script dice:  \033[0m"
echo -e "\033[40m\033[35m \n¡Hola! ${Nombre} \033[0m"
