#!bin/bash 

echo -n "Hola mundo!"
